﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace test.Infrastructure
{
    public class Constants
    {
        public static string googleAppID = "AIzaSyD3hZbMYqD5TBLQ6W8NUmYf_1NPl6tZHk8";
        public static string Senderid = "116381815678";
        public static string icon = "icon";
        public static string delete_event_title = "Event Cancelled";
        public static string delete_event_body = "Sorry the admin has cancelled the event ";
        public static string update_event_title;
        public static string Update_event_body;
        public static string preferredcategory_event_title;
        public static string preferredcategory_event_body;
        public static string minno_event_body;
        public static string minno_event_title;
        public static string notmin_event_title;
        public static string notmin_event_body;
        public static string watch_event_title;
        public static string watch_event_body;
    }
}