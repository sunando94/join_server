﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test.Models
{
    public class Location
    {
        public double longitude { get; set; }
        public double latitude { get; set; }
    }
}
