﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace test.Models
{
    public class Age
    {
        public int startage { get; set; }
        public int endage { get; set; }
    }
}
